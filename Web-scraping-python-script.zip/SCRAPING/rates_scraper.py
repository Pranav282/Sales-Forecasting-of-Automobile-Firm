from urllib.request import Request, urlopen
from bs4 import BeautifulSoup


req = Request('https://www.beginnersbuck.com/rbi-interest-rates-history/', headers={'User-Agent': 'Mozilla/5.0'})
webpage = urlopen(req).read()
soup = BeautifulSoup(webpage,"html.parser")

filename="rates_data.csv"
f=open(filename,"w")
headers="Period,Rate\n"
f.write(headers)

a=soup.findAll("tbody")
b=a[0]
c=b.findAll("tr")


for i in [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
    for j in [0,1]:
        if j==0:
            f.write(c[i].findAll("td")[j].string+",")
        else:
            f.write(c[i].findAll("td")[j].string+","+"\n")
f.close()
