from urllib.request import urlopen
from bs4 import BeautifulSoup

web="https://www.marutisuzuki.com/corporate/media/press-releases/"

filename="data.csv"
f=open(filename,"w")
headers="Year,Month,Sales\n"
f.write(headers)

lst1=[2015,2016,2017,2018,2019,2020]
lst2=["january","february","march","april","may","june","july","august","september","august","november","december"]


for x in lst1:
    for y in lst2:
        if x==2016:
            if y=="march" or y=="april" or y=="may":
                url= web+str(x)+"/"+"maruti-suzuki-sales-in-"+y
            elif y=="january":
                url=web+str(x)+"/"+"maruti-suzuki-sales-in-"+y+"-"+str(x)
            elif y=="december":
                z=lst1[lst1.index(x)+1]
                url=web+str(z)+"/"+"maruti-suzuki-sales-"+y+"-"+str(x)
            else:
                url=web+str(x)+"/"+"maruti-suzuki-sales-"+y+"-"+str(x)
        elif x==2015:
            if  y=="december":
                z=lst1[lst1.index(x)+1]
                url=web+str(z)+"/"+"maruti-suzuki-sales-"+y+"-"+str(x)
            else:
                url=web+str(x)+"/"+"maruti-suzuki-sales-in-"+y+"-"+str(x)
        else:
               url=web+str(x)+"/"+"maruti-suzuki-sales-"+y+"-"+str(x)
        try:
            html = urlopen(url).read()
            soup = BeautifulSoup(html,"html.parser")
            b=soup.findAll("tr",{"bgcolor":"#FBFAF8"})
            c=b[0].find("td",{"align":"center"})
            d=c.string
            e=int(d)

            f.write(str(x) +"," +y +","+ str(e) +"\n")
        except:

            f.write(str(x) + ","+y +","+ "error"+ "\n")
            continue
f.close()
