from urllib.request import urlopen
from bs4 import BeautifulSoup

url="http://statisticstimes.com/economy/quarterly-gdp-growth-of-india.php"
html = urlopen(url).read()
soup = BeautifulSoup(html,"html.parser")

filename="gdp_data.csv"
f=open(filename,"w")
headers="Year,1,2,3,4\n"
f.write(headers)

total=soup.findAll("tbody")
year=total[0].findAll("tr")

for i in [4,5,6,7,8]:
    print(year[i].find("td").string)
    f.write(year[i].find("td").string + ",")
    for j in [6,7,8,9]:
      print(year[i].findAll("td")[j].string)
      if j==9:
          f.write(year[i].findAll("td")[j].string +","+"\n")
      else:
         f.write(year[i].findAll("td")[j].string +",")
f.close()
